# Mob Loot Bags Addon — Forge 1.16.5

Este projeto e um codigo-fonte de addon para Minecraft Java 1.16.5 / Forge. Ele ainda precisa passar pela compilacao no GitHub Actions e por teste dentro do jogo.

## Compilar pelo Android usando GitHub

1. No navegador do celular, entre em https://github.com e crie um repositorio novo chamado `MobLootBagsAddon`.
2. Escolha `Public` ou `Private` e crie o repositorio vazio (nao marque para adicionar README, .gitignore ou license).
3. Extraia este ZIP no celular usando o gerenciador de arquivos.
4. Envie para a raiz do repositorio o CONTEUDO da pasta `MobLootBagsAddon` (os arquivos `build.gradle`, `settings.gradle` e as pastas `src` e `.github`). Nao envie a pasta externa como uma pasta extra.
5. O arquivo `.github/workflows/build.yml` configura a compilacao automatica com JDK 8 e Gradle 6.9.1.
6. Abra a aba `Actions` do repositorio, selecione `Build Mob Loot Bags Addon` e toque em `Run workflow`. Se voce ja enviou os arquivos para a branch `main`, o fluxo tambem pode iniciar automaticamente.
7. Quando terminar, abra a execucao concluida e baixe o artefato `MobLootBagsAddon-Forge-1.16.5`. Dentro dele estara o `.jar`, caso a compilacao tenha sido bem-sucedida.

## Importante

- O ZIP deste projeto NAO e um mod instalavel. Somente o JAR gerado por uma compilacao bem-sucedida pode ser colocado na pasta `mods`.
- O workflow compila o projeto; nao prova sozinho que todas as recompensas estao corretas no jogo. Teste primeiro em uma copia do mundo.
- Dependencia esperada: Forge 1.16.5 e Mob Loot Bags 1.10.1.
- Se o GitHub Actions falhar, abra a execucao, copie as primeiras linhas do erro vermelho (ou envie capturas de tela) para que possamos corrigir.
