package br.com.moblootbagsaddon;

import net.minecraft.item.Item;
import net.minecraft.loot.ConstantRange;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.ItemLootEntry;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.LootTableLoadEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@Mod(MobLootBagsAddon.MODID)
public class MobLootBagsAddon {
    public static final String MODID = "moblootbagsaddon";

    // IDs dos mods vistos na lista enviada. Edite esta lista se adicionar outros mods.
    private static final Set<String> MOD_NAMESPACES = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
            "mekanism", "mekanismadditions", "mekanismgenerators", "mekanismtools",
            "thermal", "thermalexpansion", "mysticalagriculture", "botania",
            "alexsmobs", "rats", "avaritia", "apotheosis", "quark",
            "ironchest", "ironfurnaces", "tconstruct", "projecte", "artifacts"
    )));

    public MobLootBagsAddon() {
    }

    @Mod.EventBusSubscriber(modid = MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class LootHandler {
        @SubscribeEvent
        public static void onLootTableLoad(LootTableLoadEvent event) {
            ResourceLocation tableId = event.getName();
            if (!"mob_loot_bags".equals(tableId.getNamespace())) return;

            String path = tableId.getPath();
            Tier tier;
            if ("lootbags/common".equals(path)) tier = Tier.COMMON;
            else if ("un_common".equals(path)) tier = Tier.UNCOMMON;
            else if ("lootbags/rare".equals(path)) tier = Tier.RARE;
            else if ("lootbags/epic".equals(path)) tier = Tier.EPIC;
            else if ("legendary_loot_table".equals(path)) tier = Tier.LEGENDARY;
            else return;

            LootPool.Builder pool = LootPool.builder()
                    .name("moblootbagsaddon_" + tier.name().toLowerCase())
                    .rolls(ConstantRange.of(1));

            int added = 0;
            for (Item item : ForgeRegistries.ITEMS.getValues()) {
                ResourceLocation id = item.getRegistryName();
                if (id == null || !MOD_NAMESPACES.contains(id.getNamespace())) continue;
                if (!belongsInTier(id.getPath(), tier)) continue;

                pool.add(ItemLootEntry.builder(item).weight(weightFor(id.getPath(), tier)));
                added++;
            }

            // Não adiciona pool vazio e nunca substitui as recompensas originais.
            if (added > 0) event.getTable().addPool(pool.build());
        }

        private static boolean belongsInTier(String path, Tier tier) {
            String p = path.toLowerCase();
            boolean high = containsAny(p, "creative", "infinity", "singularity", "ultimate", "awakened", "insanium");
            boolean advanced = containsAny(p, "draconic", "chaotic", "supremium", "terrasteel", "elementium", "atomic", "refined");
            boolean equipment = containsAny(p, "sword", "pickaxe", "axe", "shovel", "hoe", "helmet", "chestplate", "leggings", "boots", "bow", "staff", "ring", "amulet");
            boolean component = containsAny(p, "ingot", "nugget", "dust", "plate", "gear", "circuit", "alloy", "essence", "seed", "fragment", "crystal");

            switch (tier) {
                case COMMON: return !high && !advanced && !equipment && component;
                case UNCOMMON: return !high && !advanced && (equipment || containsAny(p, "machine", "upgrade", "tool", "armor"));
                case RARE: return !high && (advanced || containsAny(p, "elite", "reinforced", "mana", "terrasteel", "ender", "nether"));
                case EPIC: return !high && (containsAny(p, "supremium", "draconic", "chaotic", "atomic", "refined", "awakened") || (equipment && advanced));
                case LEGENDARY: return high;
                default: return false;
            }
        }

        private static int weightFor(String path, Tier tier) {
            String p = path.toLowerCase();
            if (containsAny(p, "creative", "infinity", "singularity", "ultimate", "awakened", "insanium")) return 1;
            if (containsAny(p, "draconic", "chaotic", "supremium", "terrasteel")) return 2;
            if (tier == Tier.COMMON) return 12;
            if (tier == Tier.UNCOMMON) return 8;
            if (tier == Tier.RARE) return 5;
            return 3;
        }

        private static boolean containsAny(String text, String... needles) {
            for (String needle : needles) if (text.contains(needle)) return true;
            return false;
        }
    }

    private enum Tier { COMMON, UNCOMMON, RARE, EPIC, LEGENDARY }
}
